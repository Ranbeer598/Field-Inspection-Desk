"""Preprocess the Chicago food-inspection features, train the models and evaluate them
on a time-ordered hold-out (earlier 70% train, later 30% test). Run from the project root."""
import pyreadr,numpy as np,pandas as pd,json
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
import os,urllib.request
P='data/23_food_insp_features.Rds'
if not os.path.exists(P):
    urllib.request.urlretrieve('https://raw.githubusercontent.com/Chicago/food-inspections-evaluation/master/DATA/23_food_insp_features.Rds',P)
d=pyreadr.read_r(P)[None]
d=d.dropna(subset=['Latitude','Longitude','Zip']).sort_values('Inspection_ID').reset_index(drop=True)
y=(d.criticalCount>0).astype(int).values
cap=lambda c:np.minimum(d[c].values,5)
X=np.c_[(d.Risk.str.contains('High')).astype(int),(d.Risk.str.contains('Medium')).astype(int),(d.Facility_Type_Clean=='Restaurant').astype(int),
        cap('pastFail'),cap('pastCritical'),cap('pastSerious'),cap('pastMinor'),d.timeSinceLast.values,d.firstRecord.values].astype(float)
FN=['Risk: high','Risk: medium','Restaurant','Past fails','Past critical','Past serious','Past minor','Years since last','First record']
n=len(d);cut=int(n*.7);Xtr,Xte,ytr,yte=X[:cut],X[cut:],y[:cut],y[cut:]
mu,sd=Xtr.mean(0),Xtr.std(0)+1e-9
lr=LogisticRegression(C=10,max_iter=1000).fit((Xtr-mu)/sd,ytr)
hgb=HistGradientBoostingClassifier(max_iter=150,learning_rate=.06,random_state=0).fit(Xtr,ytr)
sev=np.where(Xte[:,0]==1,1,np.where(Xte[:,1]==1,.6,.2))
rule=.4*sev+.3*Xte[:,7]/2+.3*Xte[:,4]/5
K=.2
def M(s):
    o=np.argsort(-s,kind='stable');t=int(np.ceil(len(s)*K));h=yte[o[:t]].sum()
    return dict(auc=round(float(roc_auc_score(yte,s)),4),recall=round(h/yte.sum()*100,2),prec=round(h/t*100,2),lift=round((h/t)/yte.mean(),3))
rg=np.random.default_rng(1);rs=[M(rg.random(len(yte))) for _ in range(200)]
rnd={k:round(float(np.mean([r[k] for r in rs])),3) for k in rs[0]};rnd['sd_recall']=round(float(np.std([r['recall'] for r in rs])),3)
rr=M(-np.arange(len(yte),dtype=float))  # fixed list order, first 20%
R=dict(random=rnd,roundrobin=rr,rule=M(rule),logreg=M(lr.predict_proba((Xte-mu)/sd)[:,1]),hgb=M(hgb.predict_proba(Xte)[:,1]))
def gains(s):
    o=np.argsort(-s,kind='stable');c=np.cumsum(yte[o])/yte.sum();return [round(float(c[int(len(s)*f)-1])*100,1) for f in np.arange(.05,1.001,.05)]
G=dict(logreg=gains(lr.predict_proba((Xte-mu)/sd)[:,1]),rule=gains(rule),hgb=gains(hgb.predict_proba(Xte)[:,1]))
def rate(mask,lab):return [lab,round(float(y[mask].mean()*100),1),int(mask.sum())]
EDA=dict(risk=[rate(X[:,0]==1,'High'),rate(X[:,1]==1,'Medium'),rate((X[:,0]==0)&(X[:,1]==0),'Low')],
 fac=[rate(X[:,2]==1,'Restaurant'),rate(X[:,2]==0,'Other')],
 pastc=[rate(X[:,4]==0,'0'),rate(X[:,4]==1,'1'),rate(X[:,4]>=2,'2+')],
 gap=[rate(X[:,7]<1,'<1 yr'),rate((X[:,7]>=1)&(X[:,7]<2),'1-2 yr'),rate(X[:,7]>=2,'2 yr+')])
rng=np.random.default_rng(7)
def rows(ix):return [[round(float(v),3) for v in X[i]]+[int(y[i]),round(float(d.Latitude[i]),4),round(float(d.Longitude[i]),4)] for i in ix]
tri=rng.choice(np.arange(cut),5000,replace=False);tei=rng.choice(np.arange(cut,n),2000,replace=False)
meta=dict(rows=n,train=cut,test=n-cut,pos=round(float(y.mean()*100),2),pos_train=round(float(ytr.mean()*100),2),pos_test=round(float(yte.mean()*100),2),k=K)
DATA=dict(fn=FN,meta=meta,res=R,gains=G,eda=EDA,py=dict(mu=[round(float(v),5) for v in mu],sd=[round(float(v),5) for v in sd],w=[round(float(v),4) for v in lr.coef_[0]],b=round(float(lr.intercept_[0]),4)),train=rows(tri),test=rows(tei))
os.makedirs('results',exist_ok=True)
json.dump(DATA,open('results/site_data.json','w'),separators=(',',':'))
json.dump(dict(meta=meta,res=R,gains=G,eda=EDA,weights=dict(zip(FN,DATA['py']['w'])),intercept=DATA['py']['b']),open('results/metrics.json','w'),indent=1)
print('Saved results/metrics.json and results/site_data.json')
