Dataset is downloaded here by src/train_model.py (see README.md).
