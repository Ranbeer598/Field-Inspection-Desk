"""EDA figures, confusion matrix and error examples. Run from the project root after train_model.py."""
import pyreadr,numpy as np,pandas as pd,json,matplotlib
matplotlib.use("Agg");import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
INK,TEAL,YEL,RED,GR="#10222f","#0f6b78","#f2c230","#cf3a33","#8a94a3"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"axes.edgecolor":"#555"})
raw=pyreadr.read_r('data/23_food_insp_features.Rds')[None]
out={"raw_rows":len(raw),"raw_cols":raw.shape[1]}
d=raw.dropna(subset=['Latitude','Longitude','Zip']).sort_values('Inspection_ID').reset_index(drop=True)
out["rows"]=len(d);out["dropped"]=len(raw)-len(d)
y=(d.criticalCount>0).astype(int).values;out["pos"]=int(y.sum());out["neg"]=int(len(y)-y.sum())
out["zips"]=int(d.Zip.nunique());out["licenses"]=int(d.License.nunique()) if 'License' in d else None
out["fac"]=d.Facility_Type_Clean.value_counts().to_dict();out["risk"]=d.Risk.value_counts().to_dict()
cols=['Risk','Facility_Type_Clean','pastFail','pastCritical','pastSerious','pastMinor','timeSinceLast','firstRecord','Latitude','Longitude','Zip','criticalCount']
ms=(raw[cols].isna().mean()*100).round(2);out["missing"]=ms.to_dict();out["missing_cells_pct"]=round(float(raw[cols].isna().values.mean()*100),3)
cap=lambda c:np.minimum(d[c].values,5)
X=np.c_[(d.Risk.str.contains('High')).astype(int),(d.Risk.str.contains('Medium')).astype(int),(d.Facility_Type_Clean=='Restaurant').astype(int),cap('pastFail'),cap('pastCritical'),cap('pastSerious'),cap('pastMinor'),d.timeSinceLast.values,d.firstRecord.values].astype(float)
n=len(d);cut=int(n*.7);Xtr,Xte,ytr,yte=X[:cut],X[cut:],y[:cut],y[cut:]
mu,sd=Xtr.mean(0),Xtr.std(0)+1e-9
lr=LogisticRegression(C=10,max_iter=1000).fit((Xtr-mu)/sd,ytr);s=lr.predict_proba((Xte-mu)/sd)[:,1]
t=int(np.ceil(len(s)*.2));o=np.argsort(-s,kind='stable');pred=np.zeros(len(s),int);pred[o[:t]]=1
TP=int(((pred==1)&(yte==1)).sum());FP=int(((pred==1)&(yte==0)).sum());FN=int(((pred==0)&(yte==1)).sum());TN=int(((pred==0)&(yte==0)).sum())
out["cm"]=dict(TP=TP,FP=FP,FN=FN,TN=TN,thr=float(s[o[t-1]]))
def prof(i):
    r=Xte[i];return dict(score=round(float(s[i]),3),risk="High" if r[0] else "Medium" if r[1] else "Low",fac="Restaurant" if r[2] else "Other",pastCrit=int(r[4]),pastFail=int(r[3]),yrs=round(float(r[7]),2),first=int(r[8]))
fp=[i for i in o if yte[i]==0][:3];fn=[i for i in np.argsort(s) if yte[i]==1][:3]
out["fp"]=[prof(i) for i in fp];out["fn"]=[prof(i) for i in fn]
hi=(Xte[:,0]==1)&(Xte[:,4]==0);out["fn_share_nohistory"]=round(float(((pred==0)&(yte==1)&(Xte[:,4]==0)).sum()/max(FN,1)*100),1)
out["test_n"]=len(yte);out["test_pos"]=int(yte.sum())
# figures
def save(n):plt.tight_layout();plt.savefig(n,dpi=200);plt.close()
f,a=plt.subplots(1,2,figsize=(6.6,2.7))
rk=d.Risk.str.extract(r'(High|Medium|Low)')[0].value_counts().reindex(['High','Medium','Low']);a[0].bar(rk.index,rk.values,color=TEAL);a[0].set_title("Risk category");a[0].set_ylabel("Inspections")
fc=d.Facility_Type_Clean.value_counts();a[1].bar(fc.index,fc.values,color=INK);a[1].set_title("Facility type");save("results/fig1.png")
plt.figure(figsize=(6.2,2.7));plt.hist(d.timeSinceLast.dropna(),bins=30,color=TEAL);plt.xlabel("Years since previous inspection (capped at 2 in source)");plt.ylabel("Inspections");save("results/fig2.png")
f,a=plt.subplots(1,2,figsize=(6.6,2.7))
a[0].bar(["No critical\nviolation","Critical\nviolation"],[out["neg"],out["pos"]],color=[GR,RED]);a[0].set_title("Target distribution");a[0].set_ylabel("Inspections")
pc=np.minimum(d.pastCritical.values,3);lab=["0","1","2","3+"];rates=[y[pc==k].mean()*100 for k in range(4)];a[1].bar(lab,rates,color=TEAL);a[1].set_title("Critical-violation rate by past criticals");a[1].set_xlabel("Past critical violations");a[1].set_ylabel("%");save("results/fig3.png")
plt.figure(figsize=(6.2,2.8));m=ms.sort_values();plt.barh(m.index,m.values,color=TEAL);plt.xlabel("Missing values (%) in source file");save("results/fig4.png")
# architecture
fig,ax=plt.subplots(figsize=(6.8,3.3));ax.axis("off");ax.set_xlim(0,100);ax.set_ylim(0,52)
def box(x,y,w,h,t,c=INK,fc="white"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.4,rounding_size=1.2",fc=fc,ec=c,lw=1.5));ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=7.6,color=INK)
def ar(x1,y1,x2,y2,c=INK,st="-|>"):ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle=st,mutation_scale=9,color=c,lw=1.2))
B=[("Data input\nChicago records\n+ synthetic\n+ CSV import",2),("Preprocessing\nvalidate, clean,\nscale",22),("Risk scoring\nrule score and\nlogistic regression",42),("Allocation\nrisk / random /\nround-robin",62),("Inspection\nmodule\nchecklist + form",82)]
for t,x in B:box(x,30,16,14,t)
for i in range(4):ar(B[i][1]+16.6,37,B[i+1][1]-0.6,37)
box(62,6,16,14,"Browser storage\ntasks, reports,\nhistory",TEAL);box(82,6,16,14,"Monitoring\ndashboard\nand evaluation",TEAL)
ar(70,29.4,70,20.6);ar(90,29.4,90,20.6,RED);ar(78.6,13,81.4,13);ax.text(91.5,24.5,"report\nsubmission",fontsize=6.5,color=RED);ar(81.4,10,78.6,10,TEAL)
ax.text(2,14,"Python (offline): trains the model on\nreal data and exports weights, which\nthe web app embeds and reuses.",fontsize=7,color=INK,va="center")
ax.text(70.5,24.5,"status\nupdates",fontsize=6.5,color=INK);save("results/fig5.png")
json.dump(out,open("results/stats.json","w"),indent=1,default=str)
print(json.dumps(out,indent=1,default=str)[:2600])

# ---- result figures (need results/metrics.json and results/sched.json) ----
M=json.load(open("results/metrics.json"));SC=json.load(open("results/sched.json"))
f,a=plt.subplots(1,2,figsize=(6.8,2.9))
x=np.arange(1,21)*5
a[0].plot([0]+list(x),[0]+list(x),color=GR,ls="--",label="Random (expected)")
a[0].plot(x,M["gains"]["rule"],color=YEL,lw=2,label="Rule-based");a[0].plot(x,M["gains"]["logreg"],color=TEAL,lw=2,label="Logistic regression")
a[0].set_xlabel("% of establishments inspected");a[0].set_ylabel("% of critical violations found");a[0].legend(frameon=False,fontsize=7);a[0].set_title("Cumulative gains (test split)")
names=["Random","Round-\nrobin","Rule-\nbased","Logistic\nreg.","Grad.\nboosting"];vals=[M["res"][k]["recall"] for k in ["random","roundrobin","rule","logreg","hgb"]]
b=a[1].bar(names,vals,color=[GR,GR,YEL,TEAL,INK]);a[1].set_ylabel("Recall@20% (%)");a[1].set_title("Critical violations found, top 20%")
for r,v in zip(b,vals):a[1].text(r.get_x()+r.get_width()/2,v+.4,f"{v:.1f}",ha="center",fontsize=7)
save("results/fig6.png")
S=SC["synthetic"];f,a=plt.subplots(1,3,figsize=(6.8,2.6))
for ax,(i,t) in zip(a,[(1,"Coverage (%)"),(2,"Repeat allocation (%)"),(3,"Priority alignment (%)")]):
    v=[float(S[k][i].split()[0]) for k in range(3)];ax.bar(["Random","Round-\nrobin","Risk-\nbased"],v,color=[GR,GR,TEAL]);ax.set_title(t,fontsize=8)
    for j,u in enumerate(v):ax.text(j,u+1,f"{u:.1f}",ha="center",fontsize=7)
save("results/fig7.png")
